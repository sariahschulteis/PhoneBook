/*
 * @author Sariah Schulteis 
 * A class that has constructors, get, and set methods
 */
package assg9_schulteiss20;

public class Person extends KeyedItem<String> {
	private String contactName;
	private String contactNumber;
/*
 * A constructor for Person class
 */
	public Person(String key) {
		super(key);
	}
	
/*
 * A constructor for Person class
 * @param contactName
 * @param contactNumber
 */
	public Person(String contactName, String contactNumber) {
		super(contactName);
		this.contactName = contactName;
		this.contactNumber = contactNumber;
	}
/*
 * Gets contactName
 * @return this.contactName
 */
	public String getContactName() {
		return this.contactName;
	}
/*
 * Gets contactNumber
 * @return this.contactNumber
 */
	public String getContactNumber() {
		return this.contactNumber;
	}
/*
 * @return this.contactName
 */
	public String setContactName() {
		return this.contactName;
	}
/*
 * @return this.contactNumber
 */
	public String setContactNumber() {
		return this.contactNumber;
	}

}
