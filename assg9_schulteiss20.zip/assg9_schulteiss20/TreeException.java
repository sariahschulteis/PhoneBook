package assg9_schulteiss20;

public class TreeException extends RuntimeException {
	  public TreeException(String s) {
	    super(s);
	  }  // end constructor
	} // end TreeException