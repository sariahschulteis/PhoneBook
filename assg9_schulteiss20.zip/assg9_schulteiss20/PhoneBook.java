/*
 * @author Sariah Schulteis 
 * A class that has methods for display, add, delte, search, update and save
 */
package assg9_schulteiss20;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class PhoneBook {
	private TreeIterator<Person> treeList;
	private BinarySearchTree<Person, String> tree = new BinarySearchTree<Person, String>();
	String filename = "assg9_phoneBook.txt";
	Scanner inputStream = null;
	String input;
/*
 * The method uploads the data from the input file
 * @param Filename
 */
	public void uploadFile(String Filename) {
		try {
			inputStream = new Scanner(new File(filename));
		} catch (FileNotFoundException e) {
			System.out.println("Error opening/file not found");
			System.exit(1);
		}
		while (inputStream.hasNextLine()) {
			input = inputStream.nextLine();
			String[] split = input.split("\t");

			for (int i = 0; i < split.length; i++) {

				tree.insert(new Person(split[i], split[i + 1]));
				i += 2;

			}
		}
	}
/*
 * The method displays all the contacts
 */
	public void showContacts() {

		treeList = new TreeIterator<Person>(tree);
		treeList.setInorder();
		while (treeList.hasNext()) {
			Person temp = treeList.next();
			System.out.println(temp.getContactName() + "\t" + temp.getContactNumber());
		}
	}
/*
 * The method searches for a contact using TreeIterator
 * @param contactName
 * @return temp if getContactName equals contactName
 * @return null if false
 */
	public Person contactsSearch(String contactName) {
		treeList = new TreeIterator<Person>(tree);
		treeList.setInorder();
		while (treeList.hasNext()) {
			Person temp = treeList.next();
			if (temp.getContactName().equals(contactName)) {
				System.out.println(temp.getContactName() + "\t" + temp.getContactNumber());
				return temp;

			}

		}
		return null;
	}
/*
 * The method adds a contact 
 * @param contactName
 * @param contactNumber
 * @return true if contactsSearch == null
 * @return false if not
 */
	public boolean addContact(String contactName, String contactNumber) {
		if (contactsSearch(contactNumber) == null) {
			tree.insert(new Person(contactName, contactNumber));
			System.out.println("New contact added");
			return true;
		}
		System.out.println("Contact already exists");
		return false;
	}
/*
 * The method deletes a contact
 * @param contactName
 * @return true if contactsSearch is not null
 * @return false if not
 */
	public boolean deleteContact(String contactName) {
		if (contactsSearch(contactName) != null) {
			tree.delete(contactName);
			System.out.println("Contact deleted");
			return true;
		}
		return false;
	}
/*
 * The method updates the contact
 * @param contactName
 * @param contactNumber
 */
	public void updateContact(String contactName, String contactNumber) {
		treeList = new TreeIterator<Person>(tree);
		treeList.setInorder();
		while (treeList.hasNext()) {
			Person temp = treeList.next();
			if (temp.getContactName().equals(contactName)) {
				tree.delete(contactName);

				tree.insert(new Person(contactName, contactNumber));
			}
		}
	}
/*
 * The method saves everything back into the file
 */
	public void save() throws IOException {
		treeList = new TreeIterator<Person>(tree);
		treeList.setInorder();
		FileWriter fr = null;
		try {
			fr = new FileWriter(new File(filename));
		} catch (IOException e) {
			System.out.println("Error saving file");
			System.exit(1);
		}
		while (treeList.hasNext()) {
			Person temp = treeList.next();
			fr.write(temp.getContactName() + "\t" + temp.getContactNumber() + "\n");

		}
		fr.close();
	}
}
