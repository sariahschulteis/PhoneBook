/*
 * @author Sariah Schulteis 
 * A class with the main method and prints out all of the methods in PhoneBook
 */
package assg9_schulteiss20;

import java.io.IOException;
import java.util.Scanner;
/*
public class PhoneBookManager {
	public static void main(String[] args) throws IOException {
		PhoneBook t = new PhoneBook(); 
		String filename = "assg9_phoneBook.txt";
		t.loadData(filename);
		do {
		 System.out.println("Menu:\n" + "1. Display the phone book\n" + 
		 "2. Add a contact\n" + "3. Delete a contact\n" + "4. Search phone number\n"
		 + "5. Update phone number\n" + "6. Save and Exit\n");
		 Scanner keyboard = new Scanner(System.in);
		 int input = keyboard.nextInt();
		 switch (input) {
		 //This case displays.
		 case 1: t.displayRoster();
		 break;
		 //This case lets the user to add a new customer.
		 case 2:System.out.println("Enter a phone number: ");
		 Scanner input3 = new Scanner(System.in);
		 String id3 = input3.nextLine();
		 System.out.println("Enter an name: ");
		 String name1 = input3.nextLine();
		// System.out.println("Enter an Customer Number: ");
		 //String number1 = input3.nextLine();
		 t.add(id3,name1);
		 break;
		 
		 //This case lets the user delete a customer.
		 case 3: System.out.println("Enter an name: ");
		 Scanner input1 = new Scanner(System.in);
		 String id = input1.nextLine();
		 t.deleteCustomer(id);
		 System.out.println("\n");
		 break;
		 
		 //This case lets the user search for a customer.
		 case 4: System.out.println("Enter an Customer ID: ");
		 Scanner input2 = new Scanner(System.in);
		 String id2 = input2.nextLine();
		 t.searchForCustomer(id2);
		 
		 break;
		 
		 //This case lets the user update the information for the customer.
		 case 5: System.out.println("Enter an Customer ID: ");
		 Scanner input4 = new Scanner(System.in);
		 String id4 = input4.nextLine();
		 System.out.println("Enter an Customer Name: ");
		 String name2 = input4.nextLine();
		 System.out.println("Enter an Customer Number: ");
		 String number2 = input4.nextLine();
		 t.update(id4,name2,number2);
		 break;
		 
		 //This case saves and then exits the program.
		 case 6: t.save();
		 System.exit(0);
		 break;
		 }
		 }
		 while(true);
		}
}
*/
import java.util.Scanner;
/*
public class PhoneBookManager {
	static PhoneBook phoneb;

	public static void main(String[] args) {

		// TODO Auto-generated method stub

		phoneb = new PhoneBook();

		showMenu();

	}

	public static void showMenu() {

		Scanner in = new Scanner(System.in);

		int quit = 0;

		while (true) {

			System.out.println("Select Operation:");

			System.out.println("press 1 for ADD Contact");

			System.out.println("press 2 for DELETE Contact");

			System.out.println("press 3 for CHANGE Contact");

			System.out.println("press 4 for QUIT");

			String option = in.nextLine();

			switch (option) {

			case "1":

				String name;
				long phone;

				System.out.println("Enter name:");

				name = in.nextLine();

				System.out.println("Enter Phone");

				phone = Long.parseLong(in.nextLine());

				phoneb.addContact(name, phone);

				System.out.println("Contact Added!!!");

				break;

			case "2":

				System.out.println("Enter Name:");

				name = in.nextLine();

				phoneb.deleteContact(name);

				break;

			case "3":

				System.out.println("Enter Name:");

				name = in.nextLine();

				System.out.println("Enter phone:");

				phone = Long.parseLong(in.nextLine());

				phoneb.changeContact(name);

				System.out.println("Contact Updated!!");

				break;

			case "4":

				quit = 1;

				phoneb.savetofile();

				phoneb.showContactlist();

				break;

			default:
				break;

			}

			if (quit == 1) {

				break;

			}

		}

		in.close();

	}

}
*/

import java.io.IOException;
import java.util.Scanner;

public class PhoneBookManager {
	public static void main(String[] args) throws IOException {
		PhoneBook book = new PhoneBook();
		String filename = "assg9_phoneBook.txt";
		book.uploadFile(filename);
		do {
			System.out
					.println("Menu:\n" + "1. Display the phone book\n" + "2. Add a contact\n" + "3. Delete a contact\n"
							+ "4. Search phone number\n" + "5. Update phone number\n" + "6. Save and Exit\n");
			Scanner keyboard = new Scanner(System.in);
			int input = keyboard.nextInt();
			switch (input) {
			// display
			case 1:
				book.showContacts();
				break;
			// add a contact
			case 2:
				System.out.println("Enter a phone number ");
				Scanner input1 = new Scanner(System.in);
				String phone = input1.nextLine();
				System.out.println("Enter an name ");
				String contact = input1.nextLine();
				book.addContact(contact, phone);
				break;

			// delete a contact
			case 3:
				System.out.println("Enter an name ");
				Scanner input2 = new Scanner(System.in);
				String contact1 = input2.nextLine();
				book.deleteContact(contact1);
				System.out.println("\n");
				break;

			// search for a phone number
			case 4:
				System.out.println("Enter a name ");
				Scanner input3 = new Scanner(System.in);
				String contact2 = input3.nextLine();
				book.contactsSearch(contact2);

				break;

			// update phone number
			case 5:
				System.out.println("Enter a name ");
				Scanner input4 = new Scanner(System.in);
				String contact3 = input4.nextLine();
				System.out.println("Enter an phone number ");
				String phone2 = input4.nextLine();
				book.updateContact(contact3, phone2);
				break;

			// save
			case 6:
				book.save();
				System.exit(0);
				break;
			}
			System.out.println();
			System.out.println("Press enter to continue");
			Scanner keyboard2 = new Scanner(System.in);
			String enter = keyboard2.nextLine();
			if (!enter.equalsIgnoreCase(enter)) {
				System.out.println();
			}
		} while (true);
	}
}
